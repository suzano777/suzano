<?php

function postarCurl($form_url, $data_to_post){

  // Initialize cURL
  $curl = curl_init();
  // Set the options
  curl_setopt($curl,CURLOPT_URL, $form_url);

  // This sets the number of fields to post
  curl_setopt($curl,CURLOPT_POST, sizeof($data_to_post));
  // This is the fields to post in the form of an array.
  curl_setopt($curl,CURLOPT_POSTFIELDS, $data_to_post);
  curl_setopt ($curl, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt ($curl, CURLOPT_RETURNTRANSFER, 1);

  //timer out, set by Thiego
  curl_setopt($curl,CURLOPT_CONNECTTIMEOUT ,30);
  curl_setopt($curl,CURLOPT_TIMEOUT, 1200);

  //execute the post
  $result = curl_exec($curl);

  //close the connection
  curl_close($curl);

  return $result;
}

$form_url = 'http://testando.d/downloaded.php';

$windows = array('xp','7','8','8.1','10');
$windows_arquitetura = array('x86','x64');
$avs = array('','','','','avg','avast','karspesky','norton', 'avira','eset','comodo','panda','bitdefender','trendmicro');
$user = array('s3','tooo','kjch','ssss','allq','aly','plpo','ppor','wr');
$hotname = array('NOTEBOOK','PC','USUARIO','user');
$plugins = array('','','GB','GB,bb,caixa', 'GB,sicoob', '', 'GB,itau,bradesco','GB,santander','','GB,banestes', 'GB,caixa');

$data_to_post = array(
      'ip' => rand(65,255) . '.' .rand(65,255) . '.' .rand(65,255) . '.' . rand(65,255),
      'os' => $windows[rand(0,(count($windows) -1))] . ' ' . $windows_arquitetura[rand(0,(count($windows_arquitetura) -1))],
      'versao' => 'v2.988',
      'user' => $user[rand(0,(count($user) -1))],
      'hostname' => $hotname[rand(0,(count($hotname) -1))] . '-' . $user[rand(0,(count($user) -1))],
      'plugin' => $plugins[rand(0,(count($plugins) -1))],
      'av' => $avs[rand(0,(count($avs) -1))],
	  'key' => 'nome-da-chave-de-acesso'
);

$resultado = postarCurl($form_url,$data_to_post);

echo $resultado;
